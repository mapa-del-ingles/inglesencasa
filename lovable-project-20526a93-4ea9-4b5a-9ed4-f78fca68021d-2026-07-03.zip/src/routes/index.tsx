import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Zap, Clock, Users, ShieldCheck, Infinity as InfinityIcon, Lock,
  Smartphone, BookOpen, Calendar, MessageSquare, Monitor, Award,
  CheckCircle2, Check, X, Plus, AlertTriangle, Home, Menu, User, BarChart3, Play,
} from "lucide-react";
import methodMockup from "@/assets/mockup-method-premium.png";
import phoneMockup from "@/assets/mockup-phone-members.png";

export const Route = createFileRoute("/")({
  component: SalesPage,
});

const CHECKOUT_URL =
  "https://pay.hotmart.com/F98669622C?checkoutMode=10&offDiscount=790IDCT&hotfeature=51&_hi=eyJjaWQiOiIxNzQxMTEwODk1Njk0MTE5ODg3OTEwMDE4MDk1ODQwIiwiYmlkIjoiMTc0MTExMDg5NTY5NDExOTg4NzkxMDAxODA5NTg0MCIsInNpZCI6ImQ3ZDczMDIzYmM1ZTQxYzI5YjI5NzcxNWUyMDg2NGVlIn0=.1780259689060&bid=1780259692506";

function scrollToOffer() {
  document.getElementById("oferta")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

/* --- Countdown ----------------------------------------------------------- */
function useCountdown(initialSeconds: number) {
  const [s, setS] = useState(initialSeconds);
  useEffect(() => {
    const id = setInterval(() => setS((v) => (v > 0 ? v - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, []);
  const hh = String(Math.floor(s / 3600)).padStart(2, "0");
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return { hh, mm, ss };
}

/* --- Scroll reveal wrapper ---------------------------------------------- */
function Reveal({
  children,
  className = "",
  delay = 0,
  as: As = "div",
}: { children: React.ReactNode; className?: string; delay?: number; as?: React.ElementType }) {
  const ref = useRef<HTMLElement | null>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <As
      ref={ref as React.Ref<HTMLDivElement>}
      className={`reveal ${visible ? "reveal-in" : ""} ${className}`}
      style={{ animationDelay: visible ? `${delay}ms` : undefined }}
    >
      {children}
    </As>
  );
}

/* --- Reusable bits ------------------------------------------------------- */
function CtaButton({
  children = "Quiero empezar ahora",
  className = "",
}: { children?: React.ReactNode; className?: string }) {
  return (
    <button
      onClick={scrollToOffer}
      className={`btn-cta inline-flex items-center justify-center rounded-full px-8 py-4 text-base sm:text-lg uppercase tracking-wide w-full max-w-lg transition-transform duration-200 hover:scale-[1.03] active:scale-[0.98] ${className}`}
    >
      {children}
    </button>
  );
}

function CtaWrap({ children }: { children: React.ReactNode }) {
  return <div className="mt-10 flex justify-center">{children}</div>;
}

function Stars({ n = 5 }: { n?: number }) {
  return (
    <span className="text-success text-sm leading-none tracking-tight">
      {"★".repeat(n)}
      <span className="text-muted-foreground/40">{"★".repeat(5 - n)}</span>
    </span>
  );
}


/* --- Custom Phone Mockup (members area) --------------------------------- */
function PhoneMockup() {
  const modules = [
    { n: 1, title: "Fundamentos", lessons: "12 / 24 lecciones", pct: 50,
      img: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=160&h=160&fit=crop" },
    { n: 2, title: "Conversaciones reales", lessons: "8 / 24 lecciones", pct: 33,
      img: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=160&h=160&fit=crop" },
    { n: 3, title: "Inglés para trabajo remoto", lessons: "5 / 24 lecciones", pct: 21,
      img: "https://images.unsplash.com/photo-1591115765373-5207764f72e7?w=160&h=160&fit=crop" },
  ];
  return (
    <div className="float-y" style={{ transform: "rotate(-8deg)", transformOrigin: "center" }}>
      <div className="relative w-[280px] sm:w-[320px] rounded-[2.8rem] p-2 bg-neutral-900 shadow-2xl ring-1 ring-black/40"
           style={{ boxShadow: "0 40px 80px -20px rgba(0,0,0,0.45), 0 0 0 2px #1a1a1a inset" }}>
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-6 bg-neutral-900 rounded-b-2xl z-10" />
        {/* Screen */}
        <div className="rounded-[2.3rem] overflow-hidden" style={{ background: "#0d1f15" }}>
          {/* Status bar */}
          <div className="flex justify-between items-center px-6 pt-4 pb-2 text-white text-xs font-semibold">
            <span>9:41</span>
            <span className="flex gap-1 items-center">
              <span>•••</span><span>📶</span><span>🔋</span>
            </span>
          </div>
          {/* Header */}
          <div className="flex items-center justify-between px-5 pt-2 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: "#1a3a28" }}>
                <Home className="w-5 h-5" style={{ color: "#7dd99e" }} />
              </div>
              <div className="leading-tight">
                <div className="text-[13px] font-bold" style={{ color: "#7dd99e" }}>Inglés</div>
                <div className="text-[13px] font-bold" style={{ color: "#7dd99e" }}>desde Casa</div>
              </div>
            </div>
            <Menu className="w-5 h-5 text-white/80" />
          </div>
          {/* Welcome + progress */}
          <div className="px-5 flex items-center justify-between gap-3">
            <div>
              <p className="text-white text-[15px] leading-tight">Bienvenido a tu</p>
              <p className="text-white font-bold text-[17px] leading-tight">área premium</p>
              <div className="mt-1 h-[2px] w-10" style={{ background: "#7dd99e" }} />
            </div>
            <div className="relative w-[78px] h-[78px]">
              <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                <circle cx="18" cy="18" r="15.9" fill="none" stroke="#1a3a28" strokeWidth="3" />
                <circle cx="18" cy="18" r="15.9" fill="none" stroke="#7dd99e" strokeWidth="3"
                  strokeDasharray="100" strokeDashoffset="68" strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-white font-bold text-base leading-none">32%</span>
                <span className="text-white/70 text-[8px] mt-0.5">completado</span>
              </div>
            </div>
          </div>
          {/* Section title */}
          <div className="px-5 mt-4">
            <p className="text-white font-bold text-[13px]">Tu progreso general</p>
            <p className="text-white/60 text-[10px] leading-snug mt-1">Sigue aprendiendo y alcanza<br/>la fluidez en inglés desde casa.</p>
          </div>
          {/* Module cards */}
          <div className="px-4 mt-3 space-y-2.5">
            {modules.map((m) => (
              <div key={m.n} className="flex items-center gap-2.5 rounded-xl p-2" style={{ background: "#142a1d" }}>
                <div className="relative w-14 h-14 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={m.img} alt="" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <Play className="w-4 h-4 text-white fill-white" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[9px]" style={{ color: "#7dd99e" }}>Módulo {m.n}:</p>
                  <p className="text-white font-bold text-[11px] leading-tight">{m.title}</p>
                  <div className="mt-1 h-[2px] rounded-full" style={{ background: "#1a3a28" }}>
                    <div className="h-full rounded-full" style={{ background: "#7dd99e", width: `${m.pct}%` }} />
                  </div>
                  <p className="text-white/60 text-[8px] mt-1">{m.lessons}</p>
                </div>
                <div className="w-5 h-5 rounded-full border flex items-center justify-center flex-shrink-0"
                     style={{ borderColor: "#7dd99e" }}>
                  <Check className="w-3 h-3" style={{ color: "#7dd99e" }} />
                </div>
              </div>
            ))}
          </div>
          {/* Bottom nav */}
          <div className="mt-3 px-2 pt-2 pb-4 border-t flex justify-around" style={{ borderColor: "#1a3a28" }}>
            {[
              { I: Home, l: "Inicio", active: true },
              { I: BookOpen, l: "Mis cursos" },
              { I: BarChart3, l: "Progreso" },
              { I: User, l: "Mi cuenta" },
            ].map(({ I, l, active }) => (
              <div key={l} className="flex flex-col items-center gap-0.5">
                <I className="w-4 h-4" style={{ color: active ? "#7dd99e" : "rgba(255,255,255,0.5)" }} />
                <span className="text-[8px]" style={{ color: active ? "#7dd99e" : "rgba(255,255,255,0.5)" }}>{l}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* --- Payment Badges ----------------------------------------------------- */
function PaymentBadges() {
  return (
    <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap">
      {/* VISA */}
      <div className="bg-white border border-border rounded-md px-3 py-2 shadow-sm flex items-center justify-center h-10 w-16">
        <span className="font-extrabold italic text-[15px]" style={{ color: "#1a1f71", letterSpacing: "-0.5px" }}>VISA</span>
      </div>
      {/* Mastercard */}
      <div className="bg-white border border-border rounded-md px-3 py-2 shadow-sm flex items-center justify-center h-10 w-16">
        <div className="relative flex items-center">
          <div className="w-5 h-5 rounded-full" style={{ background: "#eb001b" }} />
          <div className="w-5 h-5 rounded-full -ml-2" style={{ background: "#f79e1b", mixBlendMode: "multiply" }} />
        </div>
      </div>
      {/* AMEX */}
      <div className="rounded-md px-3 py-2 shadow-sm flex items-center justify-center h-10 w-16" style={{ background: "#2e77bb" }}>
        <span className="font-extrabold text-white text-[9px] tracking-tighter text-center leading-none">AMERICAN<br/>EXPRESS</span>
      </div>
      {/* PayPal */}
      <div className="bg-white border border-border rounded-md px-3 py-2 shadow-sm flex items-center justify-center h-10 w-16">
        <span className="font-extrabold italic text-[13px] leading-none">
          <span style={{ color: "#003087" }}>Pay</span><span style={{ color: "#009cde" }}>Pal</span>
        </span>
      </div>
    </div>
  );
}

/* --- Page ---------------------------------------------------------------- */
function SalesPage() {
  const { hh, mm, ss } = useCountdown(7 * 3600 + 34 * 60 + 23);

  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    els.forEach((el) => el.classList.add("reveal"));
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("reveal-in");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -60px 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);


  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top bar */}
      <div className="bg-primary text-primary-foreground py-2 px-4 text-xs sm:text-sm font-medium flex items-center justify-between gap-3 max-w-3xl mx-auto">
        <span className="inline-flex items-center">
          <Zap className="w-4 h-4 mr-1" aria-hidden />
          Oferta especial activa
        </span>
        <span className="inline-flex items-center gap-1">
          <Clock className="w-4 h-4" aria-hidden />
          <span className="font-mono tabular-nums">{hh}:{mm}:{ss}</span>
        </span>
      </div>

      {/* Hero */}
      <section className="px-5 py-14 sm:py-20 pt-10 sm:pt-14">
        <div className="max-w-3xl mx-auto">
          <div className="flex justify-center mb-5">
            <div className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-3 py-1.5 rounded-full text-xs font-semibold">
              <Users className="w-3.5 h-3.5" /> +1.600 personas en Latinoamérica
            </div>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold leading-tight text-primary text-center">
            El método que te enseña a hablar inglés solo, desde casa, en solo{" "}
            <span className="text-success">20 minutos al día</span>
          </h1>
          <p className="mt-6 text-base sm:text-lg text-muted-foreground text-center max-w-2xl mx-auto">
            <strong className="text-foreground">Sin profesor. Sin mensualidades. Sin horarios fijos.</strong>{" "}
            Ya ayudó a más de 1.600 personas en América Latina a aprender a su propio ritmo, sin depender de nadie.
          </p>

          <p className="mt-6 text-center text-xs sm:text-sm font-bold text-muted-foreground">
            👇 Mira el video de abajo para entender exactamente cómo funciona el método antes de continuar.
          </p>

          <div className="mt-6 mx-auto rounded-2xl overflow-hidden shadow-card bg-card max-w-md" style={{ aspectRatio: "4 / 5" }}>
            <iframe
              src="https://cf-embed.play.hotmart.com/embed/rRA3wm8gL1"
              title="Inglés desde Casa — Video"
              allow="autoplay; fullscreen"
              allowFullScreen
              className="w-full h-full"
            />
          </div>

          <div className="mt-8 flex justify-center">
            <CtaButton />
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-success" /> Garantía 7 días</span>
            <span className="inline-flex items-center gap-1.5"><InfinityIcon className="w-4 h-4 text-success" /> Acceso de por vida</span>
            <span className="inline-flex items-center gap-1.5"><Lock className="w-4 h-4 text-success" /> Pago seguro</span>
          </div>

        </div>
      </section>

      {/* Opportunity */}
      <section data-reveal className="px-5 py-6">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary uppercase leading-tight">
            Cada día que pasa, el inglés abre puertas que antes parecían cerradas
          </h2>
          <p className="mt-5 text-muted-foreground">
            Hay oportunidades que no avisan cuando llegan. Simplemente aparecen para quienes están preparados.
          </p>
          <p className="mt-4 text-muted-foreground">
            El inglés es hoy una de las habilidades que más diferencia hace en el acceso a{" "}
            <strong className="text-foreground">nuevas oportunidades laborales</strong>, proyectos internacionales y nuevos horizontes de vida.
          </p>
          <p className="mt-5 font-semibold text-foreground">
            No se trata de ser el mejor. Se trata de estar listo cuando la oportunidad aparece.
          </p>
        </div>
      </section>

      {/* Members area */}
      <section data-reveal className="px-5 py-6">
        <div className="max-w-5xl mx-auto">
          <div className="flex justify-center mb-2">
            <img
              src={phoneMockup}
              alt="Área de miembros en el celular"
              className="float-y w-[360px] sm:w-[460px] h-auto drop-shadow-2xl"
            />

          </div>
          <div className="max-w-2xl mx-auto text-left">
            <div className="inline-flex items-center gap-1.5 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold mb-4">
              <Smartphone className="w-3.5 h-3.5" /> ÁREA DE MIEMBROS
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-primary leading-tight">
              Todo en tu bolsillo, listo para abrir y continuar donde lo dejaste.
            </h2>
            <p className="mt-4 text-muted-foreground">
              Diseñada para que aproveches los huecos del día: 5 minutos en la fila, 10 en el bus, 20 antes de dormir. Tu progreso se guarda automáticamente y siempre sabes cuál es el siguiente paso.
            </p>
            <ul className="mt-6 space-y-3 max-w-md">
              {[
                "Lecciones agrupadas por módulos prácticos",
                "Barra de progreso para mantener el ritmo",
                "Acceso inmediato apenas confirmes tu compra",
              ].map((t) => (
                <li key={t} className="flex gap-2 text-sm">
                  <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-10 flex justify-center max-w-2xl mx-auto">
          <CtaButton />
        </div>

      </section>

      {/* History / validated */}
      <section data-reveal className="px-5 py-12">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-1.5 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold mb-4">
            <Award className="w-3.5 h-3.5" /> LA HISTORIA DETRÁS DEL MÉTODO
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary leading-tight">
            Un método validado con resultados reales
          </h2>
          <p className="mt-5 text-muted-foreground">
            Detrás de <strong className="text-foreground">Inglés desde Casa</strong> hay un grupo de profesores que se unieron con un objetivo simple: organizar todo lo que realmente funciona para aprender inglés, en un solo lugar. Después de años enseñando y validando con +1.600 estudiantes, este método es el resultado.
          </p>

          <div className="mt-8 grid grid-cols-3 gap-3 sm:gap-4">
            {[
              { v: "+1.600", l: "Estudiantes" },
              { v: "20 min", l: "Por día" },
              { v: "4.9★", l: "Valoración" },
            ].map((s) => (
              <div key={s.l} className="bg-card border border-border rounded-2xl py-5 px-2 shadow-card">
                <div className="text-xl sm:text-2xl font-extrabold text-primary">{s.v}</div>
                <div className="text-xs sm:text-sm text-muted-foreground mt-1">{s.l}</div>
              </div>
            ))}
          </div>

          <p className="mt-10 text-sm font-semibold tracking-widest text-primary">ESTUDIANTES EN TODA LATINOAMÉRICA</p>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {[
              ["🇲🇽", "México"], ["🇨🇴", "Colombia"], ["🇦🇷", "Argentina"], ["🇵🇪", "Perú"],
              ["🇨🇱", "Chile"], ["🇪🇨", "Ecuador"], ["🇻🇪", "Venezuela"], ["🇩🇴", "Rep. Dominicana"],
              ["🇺🇾", "Uruguay"], ["🇬🇹", "Guatemala"], ["🇧🇴", "Bolivia"], ["🇵🇾", "Paraguay"],
              ["🇨🇷", "Costa Rica"], ["🇵🇦", "Panamá"],
            ].map(([flag, name]) => (
              <span key={name} className="bg-card border border-border rounded-full px-3 py-1.5 text-sm">
                <span className="mr-1">{flag}</span> {name}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* What you receive */}
      <section data-reveal className="px-5 py-12">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary text-center leading-tight">
            Todo lo que recibes hoy
          </h2>
          <p className="mt-3 text-muted-foreground text-center">
            Acceso inmediato. Desde cualquier dispositivo. Para siempre.
          </p>

          <div className="mt-8 space-y-4">
            {[
              {
                tag: "PRINCIPAL", tagColor: "bg-primary text-primary-foreground",
                icon: Monitor,
                title: "Área de miembros completa",
                desc: "Todo lo que necesitas en un solo lugar: video-clases cortas y directas, organizadas en módulos prácticos, estrategias, plan inicial, plataformas, checklists y materiales. Disponible 24/7, para que avances cuando tú quieras.",
              },
              {
                tag: "INCLUIDO", tagColor: "bg-accent text-accent-foreground",
                price: "$29.90",
                icon: BookOpen,
                title: 'E-book "Inglés desde Casa"',
                desc: "La guía digital oficial con toda la estructura del método. Descárgala y estudia incluso sin internet, donde y cuando quieras.",
              },
              {
                tag: "BONUS", tagColor: "bg-success text-white",
                price: "$17.90",
                icon: Calendar,
                title: "BONUS 1: Plan de estudios de inglés de 12 meses",
                desc: "Cronograma guiado semana a semana: qué video ver, qué leer y cómo organizar tus 20 minutos diarios. Para que nunca te quedes sin saber qué hacer.",
              },
              {
                tag: "BONUS", tagColor: "bg-success text-white",
                price: "$17.90",
                icon: MessageSquare,
                title: "BONUS 2: Manual de las frases más usadas en inglés",
                desc: "Compilación estratégica de expresiones reales usadas por nativos en el trabajo y la vida cotidiana. Para empezar a comunicarte desde la primera semana.",
              },
              {
                tag: "DE POR VIDA", tagColor: "bg-primary-dark text-primary-foreground",
                icon: InfinityIcon,
                title: "Actualizaciones constantes",
                desc: "Tu acceso es vitalicio. Cada nueva mejora o material que sumemos llega a ti sin costo adicional.",
              },
            ].map((it) => {
              const Icon = it.icon;
              return (
                <div key={it.title} className="bg-card border border-border rounded-2xl p-5 sm:p-6 shadow-card">
                  <div className="flex gap-4">
                    <div className="w-11 h-11 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className={`text-[10px] font-bold tracking-wider px-2 py-0.5 rounded ${it.tagColor}`}>{it.tag}</span>
                        {it.price && (
                          <span className="text-xs text-muted-foreground">
                            Valor <span className="line-through">{it.price} USD</span>
                          </span>
                        )}
                      </div>
                      <h3 className="font-bold text-foreground">{it.title}</h3>
                      <p className="text-sm text-muted-foreground mt-2">{it.desc}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-10 flex justify-center">
            <CtaButton />
          </div>
        </div>
      </section>

      {/* Transformation */}
      <section data-reveal className="px-5 py-12">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary text-center leading-tight">
            Esto es lo que empieza a cambiar cuando das el primer paso hoy:
          </h2>
          <ul className="mt-8 space-y-4">
            {[
              "Ver una oportunidad nueva y sentir que esta vez sí estás preparado para tomarla, sin sentir que el idioma te deja fuera antes de empezar.",
              "Presentar un examen, una entrevista o un proyecto académico sabiendo que el inglés ya no es una barrera.",
              "Leer y comprender contenido en inglés sin necesitar traducir todo en tu cabeza.",
              "Sentir que finalmente tienes el control sobre tu propio aprendizaje, sin depender de nadie.",
              "Hablar con más confianza, sin el miedo a equivocarte o quedarte en blanco.",
              "Sentir que finalmente puedes entender lo que escuchas, sin depender de subtítulos ni traducciones.",
            ].map((t) => (
              <li key={t} className="flex gap-3 bg-card border border-border rounded-xl p-4 shadow-card">
                <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                <span className="text-sm text-foreground">{t}</span>
              </li>
            ))}
          </ul>
          <div className="mt-10 flex justify-center">
            <CtaButton />
          </div>
        </div>
      </section>

      {/* Method hero image */}
      <section data-reveal className="px-5 py-6">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-1.5 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold mb-4">
            EL MÉTODO
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary leading-tight">
            No es un curso más. Es un camino ya recorrido por otros.
          </h2>
          <div className="mt-8 flex justify-center">
            <img
              src={methodMockup}
              alt="Inglés desde Casa — ebook premium y plataforma multidispositivo"
              className="w-full h-auto max-w-3xl float-y-slow drop-shadow-2xl"
              width={1280}
              height={1024}
              loading="lazy"
            />
          </div>

          <p className="mt-8 text-muted-foreground">
            <strong className="text-foreground">Inglés desde Casa</strong> no es un curso tradicional. Es el resultado de organizar, de forma <strong className="text-foreground">lógica y secuencial</strong>, las técnicas y herramientas que realmente funcionan para aprender inglés solo, sin perder tiempo probando lo que no sirve.
          </p>
          <p className="mt-4 text-muted-foreground">
            Ya fue puesto a prueba por más de <strong className="text-foreground">1.600 personas</strong> en América Latina.{" "}
            <strong className="text-foreground">Tú no tienes que investigar nada, ni organizar nada por tu cuenta.</strong>{" "}
            El camino ya está hecho. Solo tienes que seguirlo.
          </p>
        </div>
      </section>

      {/* Comparison */}
      <section data-reveal className="px-5 py-12">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary text-center leading-tight">
            Por qué este método funciona donde otros fallaron
          </h2>
          <p className="mt-3 text-muted-foreground text-center">Compara las opciones que ya conoces:</p>

          <div className="mt-8 bg-card border border-border rounded-2xl overflow-hidden shadow-card">
            <div className="grid grid-cols-[1.5fr_1fr_1fr] bg-primary text-primary-foreground text-xs sm:text-sm font-semibold">
              <div className="p-3 sm:p-4">Característica</div>
              <div className="p-3 sm:p-4 text-center">Apps / YouTube / Cursos</div>
              <div className="p-3 sm:p-4 text-center">Inglés desde Casa</div>
            </div>
            {[
              "Plan organizado paso a paso",
              "Sabes exactamente qué hacer cada día",
              "Sin perder tiempo buscando contenido disperso",
              "Sin mensualidades ni pagos recurrentes",
              "Acceso de por vida con un único pago",
              "Frases reales que usan los nativos todos los días",
              "Material disponible para estudiar sin conexión",
              "Adaptado a quien tiene poco tiempo disponible",
              "Puedes empezar sin saber nada de inglés",
              "Avanzas a tu propio ritmo, sin horarios fijos",
            ].map((row, i) => (
              <div key={row} className={`grid grid-cols-[1.5fr_1fr_1fr] text-xs sm:text-sm border-t border-border ${i % 2 ? "bg-background" : ""}`}>
                <div className="p-3 sm:p-4 text-foreground">{row}</div>
                <div className="p-3 sm:p-4 flex items-center justify-center">
                  <X className="w-5 h-5 text-destructive" />
                </div>
                <div className="p-3 sm:p-4 flex items-center justify-center bg-accent/40">
                  <Check className="w-5 h-5 text-success" />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-10 flex justify-center">
            <CtaButton />
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section data-reveal className="px-5 py-12">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary text-center leading-tight">
            Historias reales de personas como tú
          </h2>
          <p className="mt-3 text-muted-foreground text-center">Esto es lo que están contando los estudiantes:</p>

          <div className="mt-8 grid sm:grid-cols-2 gap-5">
            {[
              { name: "Camila R.", country: "México", flag: "🇲🇽",
                avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=160&h=160&fit=crop&crop=faces", stars: 5,
                text: "Llevaba años intentando con apps y videos sueltos de YouTube, pero siempre me perdía. Lo que más me ayudó fue tener un plan claro de qué hacer cada día. Después de unos meses ya logré tener una entrevista en inglés y hoy trabajo para una empresa de fuera. Súper recomendado." },
              { name: "Jorge M.", country: "Colombia", flag: "🇨🇴",
                avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=160&h=160&fit=crop&crop=faces", stars: 4,
                text: "La verdad no tenía mucho tiempo ni plata para una academia. Con 20 minutos al día y siguiendo los pasos del método, ya puedo mantener conversaciones básicas sin trabarme tanto. Estoy aplicando a empleos remotos, a ver qué pasa." },
              { name: "Andrea S.", country: "Perú", flag: "🇵🇪",
                avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=160&h=160&fit=crop&crop=faces", stars: 5,
                text: "Pensaba que a mi edad ya no podía aprender. Lo bueno es que el plan es paso a paso y no tienes que pensar mucho qué viene después. Hoy entiendo casi todo lo que veo en Netflix sin subtítulos y eso me da mucha confianza." },
              { name: "Diego P.", country: "Argentina", flag: "🇦🇷",
                avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&h=160&fit=crop&crop=faces", stars: 4,
                text: "Probé otros cursos caros antes y siempre los dejaba por la mitad. Lo de este es que es corto y directo, no te aburre. Conseguí cambiar de trabajo a un call center internacional y la diferencia en el sueldo se nota bastante." },
            ].map((t) => (
              <div key={t.name} className="bg-card border border-border rounded-2xl p-5 shadow-card">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img src={t.avatar} alt={t.name} className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <div className="font-bold text-primary">{t.name}</div>
                      <div className="text-xs text-muted-foreground inline-flex items-center gap-1">
                        <span>{t.country}</span> <span aria-hidden>{t.flag}</span>
                      </div>
                    </div>
                  </div>
                  <Stars n={t.stars} />
                </div>
                <p className="mt-3 text-[13px] text-foreground/90 leading-relaxed">{t.text}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 text-xs italic text-muted-foreground text-center">
            * Resultados varían según el compromiso y esfuerzo de cada estudiante.
          </p>
          <div className="mt-8 flex justify-center">
            <CtaButton />
          </div>
        </div>
      </section>

      {/* OFFER */}
      <section id="oferta" data-reveal className="px-5 py-14">
        <div className="max-w-xl mx-auto text-center">
          <div className="inline-flex items-center gap-1.5 bg-destructive/10 text-destructive px-3 py-1 rounded-full text-xs font-bold mb-4">
            <Clock className="w-3.5 h-3.5" /> OFERTA POR TIEMPO LIMITADO
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary leading-tight">
            Comienza hoy por menos de lo que cuesta un café
          </h2>

          {/* Countdown */}
          <div className="mt-8 flex items-center justify-center gap-2 sm:gap-3">
            {[
              { v: hh, l: "HORAS" },
              { v: mm, l: "MIN" },
              { v: ss, l: "SEG" },
            ].map((u, i) => (
              <div key={u.l} className="flex items-center gap-2 sm:gap-3">
                <div className="text-center">
                  <div className="bg-primary text-primary-foreground rounded-xl px-3 sm:px-5 py-2 sm:py-3 font-mono text-2xl sm:text-3xl font-bold tabular-nums min-w-[60px]">
                    {u.v}
                  </div>
                  <div className="text-[10px] sm:text-xs font-bold text-primary mt-1 tracking-wider">{u.l}</div>
                </div>
                {i < 2 && <span className="text-2xl text-primary font-bold">:</span>}
              </div>
            ))}
          </div>

          {/* Offer card */}
          <div className="mt-8 relative bg-card border-2 border-success rounded-3xl p-6 sm:p-8 shadow-card text-left">
            <div className="absolute -top-3 right-4 sm:right-6 bg-destructive text-white text-xs font-bold px-3 py-1.5 rounded-full">
              Economiza $57.80 USD
            </div>
            <p className="text-center text-xs sm:text-sm font-bold tracking-widest text-primary mt-2">TU ACCESO COMPLETO</p>

            <ul className="mt-4 space-y-3 text-sm">
              {[
                { t: "Área de miembros 24/7 con video-clases", right: "Incluido" },
                { t: "E-book oficial descargable", strike: "$29.90 USD", right: "Hoy gratis" },
                { t: "BONUS 1: Plan de estudios de inglés de 12 meses", strike: "$17.90 USD", right: "Hoy gratis" },
                { t: "BONUS 2: Manual de las frases más usadas en inglés", strike: "$17.90 USD", right: "Hoy gratis" },
                { t: "Acceso de por vida", right: "Incluido" },
                { t: "Actualizaciones gratis", right: "Incluido" },
              ].map((row) => (
                <li key={row.t} className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-success mt-1 flex-shrink-0" />
                  <span className="flex-1">{row.t}</span>
                  <span className="text-right text-xs">
                    {row.strike && <span className="line-through text-muted-foreground mr-1">{row.strike}</span>}
                    <span className="font-bold text-success">{row.right}</span>
                  </span>
                </li>
              ))}
            </ul>

            <div className="mt-6 text-center">
              <p className="text-xs font-bold tracking-widest text-muted-foreground">PRECIO TOTAL REAL</p>
              <p className="mt-1 text-xl line-through text-destructive font-bold">$65.70 USD</p>
              <p className="mt-1 text-5xl sm:text-6xl font-extrabold text-primary">$7.90 USD</p>
              <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-bold text-white shadow-sm"
                   style={{ background: "linear-gradient(135deg, #ff7a18, #ff4e00)" }}>
                <AlertTriangle className="w-3.5 h-3.5" /> ÚLTIMOS CUPONES DISPONIBLES
              </div>
              <p className="mt-4 text-sm font-semibold text-success">
                Puedes pagar con tu método de pago local, en tu moneda local
              </p>

              <a
                href={CHECKOUT_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-cta mt-5 inline-flex items-center justify-center rounded-full px-8 py-4 text-base sm:text-lg uppercase tracking-wide w-full transition-transform duration-200 hover:scale-[1.03] active:scale-[0.98]"
              >
                Obtener acceso ahora
              </a>

              <div className="mt-5">
                <PaymentBadges />
              </div>
              <p className="mt-3 text-xs text-muted-foreground inline-flex items-center gap-1.5 justify-center">
                <Lock className="w-3 h-3" /> Pago seguro · Acceso inmediato
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Guarantee */}
      <section data-reveal className="px-5 py-10">
        <div className="max-w-2xl mx-auto bg-card border border-success/40 rounded-2xl p-8 text-center shadow-card">
          <div className="w-14 h-14 rounded-full bg-accent flex items-center justify-center mx-auto">
            <ShieldCheck className="w-7 h-7 text-success" />
          </div>
          <h3 className="mt-4 text-xl font-extrabold text-primary">Garantía incondicional de 7 días</h3>
          <p className="mt-3 text-sm text-muted-foreground">
            Prueba el método sin riesgo. Si en 7 días sientes que no es para ti, escribes un correo y te devolvemos el 100%, sin preguntas, sin trámites complicados. Todo el riesgo es nuestro.
          </p>
        </div>
      </section>

      {/* FAQ */}
      <section data-reveal className="px-5 py-14 bg-accent/30">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-primary text-center">Preguntas frecuentes</h2>
          <div className="mt-8 space-y-3">
            {[
              ["¿Cuánto tiempo necesito al día?", "Con 20 minutos diarios es suficiente. El plan está diseñado para personas con poco tiempo libre."],
              ["¿Sirve si parto desde cero?", "Sí. El método comienza desde el principio absoluto y te lleva paso a paso."],
              ["¿Hay pagos recurrentes?", "No. Pagas una sola vez $7.90 USD y el acceso es de por vida, sin mensualidades."],
              ["¿Puedo estudiar desde el celular?", "Sí. Funciona en celular, tablet, notebook y computador. Solo necesitas internet."],
              ["¿Y si no me gusta?", "Tienes 7 días para pedir el reembolso completo, sin preguntas."],
              ["¿Cuándo recibo el acceso?", "Inmediatamente después del pago, en tu correo electrónico."],
            ].map(([q, a]) => (
              <details key={q} className="group bg-card border border-border rounded-xl p-4 sm:p-5 shadow-card">
                <summary className="cursor-pointer list-none flex items-center justify-between gap-4 font-semibold text-foreground">
                  <span>{q}</span>
                  <Plus className="w-5 h-5 text-success transition-transform group-open:rotate-45" />
                </summary>
                <p className="mt-3 text-sm text-muted-foreground">{a}</p>
              </details>
            ))}
          </div>
          <div className="mt-10 flex justify-center">
            <CtaButton />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-5 py-10 text-center text-xs text-muted-foreground max-w-2xl mx-auto">
        <p>© {new Date().getFullYear()} Inglés desde Casa. Todos los derechos reservados.</p>
        <p className="mt-2">
          Este producto no garantiza resultados específicos. Los resultados dependen del compromiso individual de cada estudiante.
        </p>
      </footer>
    </div>
  );
}
